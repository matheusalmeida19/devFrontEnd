document.addEventListener("DOMContentLoaded", function() {

    const form = document.querySelector("form");

// Suggested code may be subject to a license. Learn more: ~LicenseLog:1899897968.
    form.addEventListener("submit", function(event) {
        event.preventDefault();

        const nome = document.querySelector("input[name='nome']").value;
        const email = document.querySelector("input[name='email']").value;
        if(nome == ""||email == ""){
            alert("Preencha todos os campos");
            return;
        }
        alert(`Obrigado,${nome}!Você se Increveu com sucesso!Usando o email ${email}`)
        //limpar formulario

        form.reset();
    })

});